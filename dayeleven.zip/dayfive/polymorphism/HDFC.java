package com.tns.dayfive.polymorphism;

public class HDFC extends RBI{
	
	public float getRateOfInterest() {
		return 6.5f;
	}
}
