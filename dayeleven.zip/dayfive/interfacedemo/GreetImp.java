package com.tns.dayfive.interfacedemo;

public class GreetImp implements Greeting{

	public String greet()
	{
		return "Hi! Welcome to the session";
	}
	
}
